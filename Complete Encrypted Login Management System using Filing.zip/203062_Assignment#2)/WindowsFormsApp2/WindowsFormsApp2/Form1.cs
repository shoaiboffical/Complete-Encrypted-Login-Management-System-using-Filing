﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Security.Cryptography;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
         
        }
      

            private void button1_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream(@"F:\Desktop\login files\text.txt", FileMode.Append, FileAccess.Write);
            StreamWriter rs = new StreamWriter(fs);

            string result = txt_user.Text + " " + txt_email.Text;
            rs.WriteLine(result);

            rs.Close();
            fs.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
          

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            txt_user.Text = Regex.Replace(txt_user.Text, " "," ");

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute hash from the bytes of text  
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it  
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into 2 hexadecimal digits  
                //for each byte  
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }

        private void btn_sinup_Click(object sender, EventArgs e)
        {
            if (txt_user.Text == "" || txt_cell.Text==""||txt_email.Text==""||text_cpass.Text=="" || text_pass.Text == "")
            {
                MessageBox.Show("some field are empty");
            }
            else
            {
                if (text_cpass.Text == text_pass.Text)
                {
                    string d = @"F:\Desktop\login files\login_info.txt";
                    bool check1 = false;
                    if (File.Exists(d))
                    {
                        FileStream fp1 = new FileStream(@"F:\Desktop\login files\login_info.txt", FileMode.Open, FileAccess.Read);
                        StreamReader sr1 = new StreamReader(fp1);

                        int counter = 0;
                        string ln;
                     
                        while ((ln = sr1.ReadLine()) != null)
                        {
                            string[] authorsList = ln.Split(' ');
                            if (authorsList[0] == txt_user.Text && authorsList[2] == txt_cell.Text)
                            {
                                check1 = true;
                                MessageBox.Show("user already exist with same name and phone number");
                            }


                            counter++;
                        }
                        fp1.Close();
                        sr1.Close();

                    }

                    




                    if (check1 == false)
                    {
                        FileStream fp = new FileStream(@"F:\Desktop\login files\login_info.txt", FileMode.Append, FileAccess.Write);
                        StreamWriter sr = new StreamWriter(fp);

                        string result = MD5Hash(text_pass.Text);




                        string data1 = txt_user.Text + " " + txt_email.Text + " " + txt_cell.Text + " " + result;

                        sr.WriteLine(data1);
                        sr.Close();
                        fp.Close();
                        txt_user.Text = "";
                        txt_email.Text = "";
                        txt_cell.Text = "";
                        text_pass.Text = "";
                        text_cpass.Text = "";
                        MessageBox.Show("successfully register");
                        

                    }








                }
                else
                {
                    MessageBox.Show("Password Not match");
                }
            }
        }

        private void txt_cell_TextChanged(object sender, EventArgs e)
        {
           txt_cell.Text= Regex.Replace(txt_cell.Text, " ", "");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            sign_in sin = new sign_in();
            sin.Show();
            this.Hide();
        }

        private void text_pass_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
