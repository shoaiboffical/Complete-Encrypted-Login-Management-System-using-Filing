﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace WindowsFormsApp2
{
    public partial class sign_in : Form
    {
        public sign_in()
        {
            InitializeComponent();
        }

        private void splitter2_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void btn_sinup_Click(object sender, EventArgs e)
        {
            Form1 fm = new Form1();
            fm.Show();
            this.Hide();
        }
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute hash from the bytes of text  
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it  
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into 2 hexadecimal digits  
                //for each byte  
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }
        private void btn_sigin_Click(object sender, EventArgs e)
        {

           
            FileStream fp1 = new FileStream(@"F:\Desktop\login files\login_info.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr1 = new StreamReader(fp1);

            int counter = 0;
            string ln;
            bool check = false;
            string result = MD5Hash(txt_pass.Text);
            while ((ln = sr1.ReadLine()) != null)
            {
                string[] authorsList = ln.Split(' ');
                if (authorsList[0] == txt_user.Text && authorsList[3] ==result )
                {

                    dashboard ds = new dashboard();
                    ds.Show();
                    this.Hide();
                    check=true;
                }


                counter++;
            }

            if (check == false)
            {
                MessageBox.Show("user Not found!");
            }

            fp1.Close();
            sr1.Close();

        }

        private void txt_user_TextChanged(object sender, EventArgs e)
        {
            txt_user.Text = Regex.Replace(txt_user.Text, " ", "");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            password ps = new password();
            ps.Show();
            this.Hide();
        }

        private void label_pass_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
