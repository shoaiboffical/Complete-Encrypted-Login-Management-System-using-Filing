﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class password : Form
    {
        public password()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btn_sigin_Click(object sender, EventArgs e)
        {
            FileStream fp1 = new FileStream(@"F:\Desktop\login files\login_info.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr1 = new StreamReader(fp1);

            int counter = 0;
            string ln;
            bool check = false;
            
            while ((ln = sr1.ReadLine()) != null)
            {
                string[] authorsList = ln.Split(' ');
                if (authorsList[0] == txt_user.Text && authorsList[2] == txt_phone.Text)
                {

                    forgetscreen ds = new forgetscreen(authorsList[0], authorsList[2]);
                    ds.Show();
                    this.Hide();
                    check = true;
                }


                counter++;
            }

            if (check == false)
            {
                MessageBox.Show("user Not found!");
            }

            fp1.Close();
            sr1.Close();

        }
    }
}
