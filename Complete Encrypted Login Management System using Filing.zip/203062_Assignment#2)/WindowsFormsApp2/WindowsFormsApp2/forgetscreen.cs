﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class forgetscreen : Form
    {
        string usernaem, user_phone;
        public forgetscreen(string name,string phone)
        {
            usernaem = name;
            user_phone = phone;
            InitializeComponent();
        }

        private void txt_user_TextChanged(object sender, EventArgs e)
        {

        }
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute hash from the bytes of text  
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it  
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into 2 hexadecimal digits  
                //for each byte  
                strBuilder.Append(result[i].ToString("x2"));
            }

            return strBuilder.ToString();
        }

   

        private void btn_sigin_Click(object sender, EventArgs e)
        {
            if (txt_newpass.Text == "" || txt_conpass.Text == "")
            {
                MessageBox.Show("show field are empty");
            }
            else
            {
                if(txt_newpass.Text ==txt_conpass.Text)
                {
                    string name="", email="", cont="";
                    string result = MD5Hash(txt_newpass.Text);

                    FileStream fp1 = new FileStream(@"F:\Desktop\login files\login_info.txt", FileMode.Open, FileAccess.Read);
                    StreamReader sr1 = new StreamReader(fp1);
                    FileStream fp2 = new FileStream(@"F:\Desktop\login files\temp.txt", FileMode.Append, FileAccess.Write);

                    StreamWriter sr2 = new StreamWriter(fp2);
                    int counter = 0;
                    string ln;
                   
                    while ((ln = sr1.ReadLine()) != null)
                    {
                        string[] authorsList = ln.Split(' ');
                        
                        if (authorsList[0] == usernaem && authorsList[2] == user_phone)
                        {
                            name = authorsList[0];
                            email = authorsList[1];
                            cont = authorsList[2];
                            string data1 = name + " " + email + " " + cont + " " + result;
                            sr2.WriteLine(data1);





                            //   MessageBox.Show("user already exist with same name and phone number");
                        }
                        else
                        {

                            name = authorsList[0];
                            email = authorsList[1];
                            cont = authorsList[2];
                            string data1 = name + " " + email + " " + cont + " " + authorsList[3];
                            sr2.WriteLine(data1);

                        }

                       

                        counter++;
                    }
                    sr1.Close();

                    fp1.Close();

                    sr2.Close();
                    fp2.Close();
                    File.Delete(@"F:\Desktop\login files\login_info.txt");
                    File.Move(@"F:\Desktop\login files\temp.txt", @"F:\Desktop\login files\login_info.txt");


                    sign_in ps = new sign_in();
                    ps.Show();
                    this.Hide();




                }
                else
                {
                    MessageBox.Show("Password not match");
                }
            }
        }
    }
}
