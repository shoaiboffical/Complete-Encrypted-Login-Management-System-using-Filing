﻿
namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_cell = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.text_cpass = new System.Windows.Forms.TextBox();
            this.text_pass = new System.Windows.Forms.TextBox();
            this.btn_sinup = new System.Windows.Forms.Button();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_user = new System.Windows.Forms.TextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.splitter4 = new System.Windows.Forms.Splitter();
            this.btn_sigin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // splitter2
            // 
            this.splitter2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.splitter2.Location = new System.Drawing.Point(0, 0);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(230, 569);
            this.splitter2.TabIndex = 17;
            this.splitter2.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Algerian", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(348, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(201, 32);
            this.label6.TabIndex = 29;
            this.label6.Text = "sign-up form";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(260, 382);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 22);
            this.label5.TabIndex = 28;
            this.label5.Text = "conform password:";
            // 
            // txt_cell
            // 
            this.txt_cell.Location = new System.Drawing.Point(451, 245);
            this.txt_cell.Margin = new System.Windows.Forms.Padding(5);
            this.txt_cell.Name = "txt_cell";
            this.txt_cell.Size = new System.Drawing.Size(218, 29);
            this.txt_cell.TabIndex = 27;
            this.txt_cell.TextChanged += new System.EventHandler(this.txt_cell_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(260, 316);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 22);
            this.label4.TabIndex = 26;
            this.label4.Text = "password :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(260, 245);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 22);
            this.label3.TabIndex = 25;
            this.label3.Text = "cellphone No :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(260, 185);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 22);
            this.label2.TabIndex = 24;
            this.label2.Text = "Email id :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(260, 125);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 22);
            this.label1.TabIndex = 23;
            this.label1.Text = "username :";
            // 
            // text_cpass
            // 
            this.text_cpass.Location = new System.Drawing.Point(451, 375);
            this.text_cpass.Margin = new System.Windows.Forms.Padding(5);
            this.text_cpass.Name = "text_cpass";
            this.text_cpass.PasswordChar = '*';
            this.text_cpass.Size = new System.Drawing.Size(218, 29);
            this.text_cpass.TabIndex = 22;
            // 
            // text_pass
            // 
            this.text_pass.Location = new System.Drawing.Point(451, 313);
            this.text_pass.Margin = new System.Windows.Forms.Padding(5);
            this.text_pass.Name = "text_pass";
            this.text_pass.PasswordChar = '*';
            this.text_pass.Size = new System.Drawing.Size(218, 29);
            this.text_pass.TabIndex = 21;
            this.text_pass.TextChanged += new System.EventHandler(this.text_pass_TextChanged);
            // 
            // btn_sinup
            // 
            this.btn_sinup.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_sinup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sinup.FlatAppearance.BorderColor = System.Drawing.Color.Navy;
            this.btn_sinup.FlatAppearance.BorderSize = 9;
            this.btn_sinup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_sinup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.btn_sinup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sinup.Location = new System.Drawing.Point(516, 441);
            this.btn_sinup.Margin = new System.Windows.Forms.Padding(5);
            this.btn_sinup.Name = "btn_sinup";
            this.btn_sinup.Size = new System.Drawing.Size(124, 37);
            this.btn_sinup.TabIndex = 20;
            this.btn_sinup.Text = "sign up";
            this.btn_sinup.UseVisualStyleBackColor = true;
            this.btn_sinup.Click += new System.EventHandler(this.btn_sinup_Click);
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(451, 185);
            this.txt_email.Margin = new System.Windows.Forms.Padding(5);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(218, 29);
            this.txt_email.TabIndex = 19;
            // 
            // txt_user
            // 
            this.txt_user.Location = new System.Drawing.Point(451, 118);
            this.txt_user.Margin = new System.Windows.Forms.Padding(5);
            this.txt_user.Name = "txt_user";
            this.txt_user.Size = new System.Drawing.Size(218, 29);
            this.txt_user.TabIndex = 18;
            this.txt_user.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Right;
            this.splitter1.Location = new System.Drawing.Point(720, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(216, 569);
            this.splitter1.TabIndex = 30;
            this.splitter1.TabStop = false;
            // 
            // splitter3
            // 
            this.splitter3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.splitter3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter3.Location = new System.Drawing.Point(230, 498);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(490, 71);
            this.splitter3.TabIndex = 31;
            this.splitter3.TabStop = false;
            // 
            // splitter4
            // 
            this.splitter4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.splitter4.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter4.Location = new System.Drawing.Point(230, 0);
            this.splitter4.Name = "splitter4";
            this.splitter4.Size = new System.Drawing.Size(490, 46);
            this.splitter4.TabIndex = 32;
            this.splitter4.TabStop = false;
            // 
            // btn_sigin
            // 
            this.btn_sigin.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btn_sigin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_sigin.FlatAppearance.BorderColor = System.Drawing.Color.Navy;
            this.btn_sigin.FlatAppearance.BorderSize = 9;
            this.btn_sigin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_sigin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.btn_sigin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sigin.Location = new System.Drawing.Point(304, 441);
            this.btn_sigin.Margin = new System.Windows.Forms.Padding(5);
            this.btn_sigin.Name = "btn_sigin";
            this.btn_sigin.Size = new System.Drawing.Size(124, 37);
            this.btn_sigin.TabIndex = 33;
            this.btn_sigin.Text = "sign in";
            this.btn_sigin.UseVisualStyleBackColor = true;
            this.btn_sigin.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.MediumTurquoise;
            this.ClientSize = new System.Drawing.Size(936, 569);
            this.Controls.Add(this.btn_sigin);
            this.Controls.Add(this.splitter4);
            this.Controls.Add(this.splitter3);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_cell);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.text_cpass);
            this.Controls.Add(this.text_pass);
            this.Controls.Add(this.btn_sinup);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_user);
            this.Controls.Add(this.splitter2);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_cell;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox text_cpass;
        private System.Windows.Forms.TextBox text_pass;
        private System.Windows.Forms.Button btn_sinup;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_user;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Splitter splitter3;
        private System.Windows.Forms.Splitter splitter4;
        private System.Windows.Forms.Button btn_sigin;
    }
}

